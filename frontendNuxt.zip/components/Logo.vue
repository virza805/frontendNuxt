<template>
  <nuxt-link to="/" class="flex md:font-size-32 text-xl font-medium items-center">
    <img src="~/assets/img/logo.png" alt="" class="mr-3">
    Bengal shop
  </nuxt-link>
</template>

<script>
  export default {
    name: "Logo"
  }

</script>

<style>

</style>
