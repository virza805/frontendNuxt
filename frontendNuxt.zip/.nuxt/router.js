import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _13d169cf = () => interopDefault(import('..\\pages\\about.vue' /* webpackChunkName: "pages/about" */))
const _b8fb75e8 = () => interopDefault(import('..\\pages\\Backend\\index.vue' /* webpackChunkName: "pages/Backend/index" */))
const _2cd48e4e = () => interopDefault(import('..\\pages\\cart.vue' /* webpackChunkName: "pages/cart" */))
const _5ba2762c = () => interopDefault(import('..\\pages\\category.vue' /* webpackChunkName: "pages/category" */))
const _cd2cbb18 = () => interopDefault(import('..\\pages\\checkout.vue' /* webpackChunkName: "pages/checkout" */))
const _679b0662 = () => interopDefault(import('..\\pages\\contact.vue' /* webpackChunkName: "pages/contact" */))
const _4d636758 = () => interopDefault(import('..\\pages\\faq.vue' /* webpackChunkName: "pages/faq" */))
const _535b03ba = () => interopDefault(import('..\\pages\\my-account.vue' /* webpackChunkName: "pages/my-account" */))
const _1e6563c5 = () => interopDefault(import('..\\pages\\offers.vue' /* webpackChunkName: "pages/offers" */))
const _d405befe = () => interopDefault(import('..\\pages\\productDetails.vue' /* webpackChunkName: "pages/productDetails" */))
const _60300376 = () => interopDefault(import('..\\pages\\Search.vue' /* webpackChunkName: "pages/Search" */))
const _7ee0216e = () => interopDefault(import('..\\pages\\sp-offers.vue' /* webpackChunkName: "pages/sp-offers" */))
const _309bb373 = () => interopDefault(import('..\\pages\\wishlist.vue' /* webpackChunkName: "pages/wishlist" */))
const _88302fc2 = () => interopDefault(import('..\\pages\\auth\\forgot-password.vue' /* webpackChunkName: "pages/auth/forgot-password" */))
const _48748e03 = () => interopDefault(import('..\\pages\\auth\\login.vue' /* webpackChunkName: "pages/auth/login" */))
const _71eb27f9 = () => interopDefault(import('..\\pages\\auth\\register.vue' /* webpackChunkName: "pages/auth/register" */))
const _1a9bc4f9 = () => interopDefault(import('..\\pages\\Backend\\addCategory.vue' /* webpackChunkName: "pages/Backend/addCategory" */))
const _2f0be3d6 = () => interopDefault(import('..\\pages\\Backend\\addFooter.vue' /* webpackChunkName: "pages/Backend/addFooter" */))
const _b2f89162 = () => interopDefault(import('..\\pages\\Backend\\addFooterTop.vue' /* webpackChunkName: "pages/Backend/addFooterTop" */))
const _1aadd344 = () => interopDefault(import('..\\pages\\Backend\\addProduct.vue' /* webpackChunkName: "pages/Backend/addProduct" */))
const _1c4e941c = () => interopDefault(import('..\\pages\\Backend\\addSlider.vue' /* webpackChunkName: "pages/Backend/addSlider" */))
const _68614b80 = () => interopDefault(import('..\\pages\\Backend\\addTask.vue' /* webpackChunkName: "pages/Backend/addTask" */))
const _70f16ec6 = () => interopDefault(import('..\\pages\\Backend\\addUser.vue' /* webpackChunkName: "pages/Backend/addUser" */))
const _01d08b06 = () => interopDefault(import('..\\pages\\Backend\\contactMessage.vue' /* webpackChunkName: "pages/Backend/contactMessage" */))
const _1dd9c6de = () => interopDefault(import('..\\pages\\Backend\\editCategory.vue' /* webpackChunkName: "pages/Backend/editCategory" */))
const _013b1afb = () => interopDefault(import('..\\pages\\Backend\\editFooter.vue' /* webpackChunkName: "pages/Backend/editFooter" */))
const _0b05f20a = () => interopDefault(import('..\\pages\\Backend\\editFooterTop.vue' /* webpackChunkName: "pages/Backend/editFooterTop" */))
const _e334fe82 = () => interopDefault(import('..\\pages\\Backend\\editProduct.vue' /* webpackChunkName: "pages/Backend/editProduct" */))
const _2304697e = () => interopDefault(import('..\\pages\\Backend\\editSlider.vue' /* webpackChunkName: "pages/Backend/editSlider" */))
const _22ce07e5 = () => interopDefault(import('..\\pages\\Backend\\editTask.vue' /* webpackChunkName: "pages/Backend/editTask" */))
const _2b5e2b2b = () => interopDefault(import('..\\pages\\Backend\\editUser.vue' /* webpackChunkName: "pages/Backend/editUser" */))
const _75057c3a = () => interopDefault(import('..\\pages\\Backend\\profile.vue' /* webpackChunkName: "pages/Backend/profile" */))
const _98c5c9ec = () => interopDefault(import('..\\pages\\Backend\\setting.vue' /* webpackChunkName: "pages/Backend/setting" */))
const _1c05415e = () => interopDefault(import('..\\pages\\Backend\\showCategory.vue' /* webpackChunkName: "pages/Backend/showCategory" */))
const _0240342e = () => interopDefault(import('..\\pages\\Backend\\showFooter.vue' /* webpackChunkName: "pages/Backend/showFooter" */))
const _a3f8e428 = () => interopDefault(import('..\\pages\\Backend\\showProduct.vue' /* webpackChunkName: "pages/Backend/showProduct" */))
const _20fa3718 = () => interopDefault(import('..\\pages\\Backend\\showSlider.vue' /* webpackChunkName: "pages/Backend/showSlider" */))
const _612df51e = () => interopDefault(import('..\\pages\\Backend\\showUser.vue' /* webpackChunkName: "pages/Backend/showUser" */))
const _d6b32a0e = () => interopDefault(import('..\\pages\\Backend\\taskList.vue' /* webpackChunkName: "pages/Backend/taskList" */))
const _1f1dd3ea = () => interopDefault(import('..\\pages\\mixins\\form.js' /* webpackChunkName: "pages/mixins/form" */))
const _70c24fd2 = () => interopDefault(import('..\\pages\\user\\reset-password.vue' /* webpackChunkName: "pages/user/reset-password" */))
const _33894494 = () => interopDefault(import('..\\pages\\index.vue' /* webpackChunkName: "pages/index" */))
const _31d2a34c = () => interopDefault(import('..\\pages\\_slug.vue' /* webpackChunkName: "pages/_slug" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'nuxt-link-active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/about",
    component: _13d169cf,
    name: "about"
  }, {
    path: "/Backend",
    component: _b8fb75e8,
    name: "Backend"
  }, {
    path: "/cart",
    component: _2cd48e4e,
    name: "cart"
  }, {
    path: "/category",
    component: _5ba2762c,
    name: "category"
  }, {
    path: "/checkout",
    component: _cd2cbb18,
    name: "checkout"
  }, {
    path: "/contact",
    component: _679b0662,
    name: "contact"
  }, {
    path: "/faq",
    component: _4d636758,
    name: "faq"
  }, {
    path: "/my-account",
    component: _535b03ba,
    name: "my-account"
  }, {
    path: "/offers",
    component: _1e6563c5,
    name: "offers"
  }, {
    path: "/productDetails",
    component: _d405befe,
    name: "productDetails"
  }, {
    path: "/Search",
    component: _60300376,
    name: "Search"
  }, {
    path: "/sp-offers",
    component: _7ee0216e,
    name: "sp-offers"
  }, {
    path: "/wishlist",
    component: _309bb373,
    name: "wishlist"
  }, {
    path: "/auth/forgot-password",
    component: _88302fc2,
    name: "auth-forgot-password"
  }, {
    path: "/auth/login",
    component: _48748e03,
    name: "auth-login"
  }, {
    path: "/auth/register",
    component: _71eb27f9,
    name: "auth-register"
  }, {
    path: "/Backend/addCategory",
    component: _1a9bc4f9,
    name: "Backend-addCategory"
  }, {
    path: "/Backend/addFooter",
    component: _2f0be3d6,
    name: "Backend-addFooter"
  }, {
    path: "/Backend/addFooterTop",
    component: _b2f89162,
    name: "Backend-addFooterTop"
  }, {
    path: "/Backend/addProduct",
    component: _1aadd344,
    name: "Backend-addProduct"
  }, {
    path: "/Backend/addSlider",
    component: _1c4e941c,
    name: "Backend-addSlider"
  }, {
    path: "/Backend/addTask",
    component: _68614b80,
    name: "Backend-addTask"
  }, {
    path: "/Backend/addUser",
    component: _70f16ec6,
    name: "Backend-addUser"
  }, {
    path: "/Backend/contactMessage",
    component: _01d08b06,
    name: "Backend-contactMessage"
  }, {
    path: "/Backend/editCategory",
    component: _1dd9c6de,
    name: "Backend-editCategory"
  }, {
    path: "/Backend/editFooter",
    component: _013b1afb,
    name: "Backend-editFooter"
  }, {
    path: "/Backend/editFooterTop",
    component: _0b05f20a,
    name: "Backend-editFooterTop"
  }, {
    path: "/Backend/editProduct",
    component: _e334fe82,
    name: "Backend-editProduct"
  }, {
    path: "/Backend/editSlider",
    component: _2304697e,
    name: "Backend-editSlider"
  }, {
    path: "/Backend/editTask",
    component: _22ce07e5,
    name: "Backend-editTask"
  }, {
    path: "/Backend/editUser",
    component: _2b5e2b2b,
    name: "Backend-editUser"
  }, {
    path: "/Backend/profile",
    component: _75057c3a,
    name: "Backend-profile"
  }, {
    path: "/Backend/setting",
    component: _98c5c9ec,
    name: "Backend-setting"
  }, {
    path: "/Backend/showCategory",
    component: _1c05415e,
    name: "Backend-showCategory"
  }, {
    path: "/Backend/showFooter",
    component: _0240342e,
    name: "Backend-showFooter"
  }, {
    path: "/Backend/showProduct",
    component: _a3f8e428,
    name: "Backend-showProduct"
  }, {
    path: "/Backend/showSlider",
    component: _20fa3718,
    name: "Backend-showSlider"
  }, {
    path: "/Backend/showUser",
    component: _612df51e,
    name: "Backend-showUser"
  }, {
    path: "/Backend/taskList",
    component: _d6b32a0e,
    name: "Backend-taskList"
  }, {
    path: "/mixins/form",
    component: _1f1dd3ea,
    name: "mixins-form"
  }, {
    path: "/user/reset-password",
    component: _70c24fd2,
    name: "user-reset-password"
  }, {
    path: "/",
    component: _33894494,
    name: "index"
  }, {
    path: "/:slug",
    component: _31d2a34c,
    name: "slug"
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
