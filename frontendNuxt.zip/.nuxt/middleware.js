const middleware = {}

middleware['authenticated'] = require('..\\middleware\\authenticated.js')
middleware['authenticated'] = middleware['authenticated'].default || middleware['authenticated']

middleware['email-verified'] = require('..\\middleware\\email-verified.js')
middleware['email-verified'] = middleware['email-verified'].default || middleware['email-verified']

middleware['guest'] = require('..\\middleware\\guest.js')
middleware['guest'] = middleware['guest'].default || middleware['guest']

middleware['super-admin'] = require('..\\middleware\\super-admin.js')
middleware['super-admin'] = middleware['super-admin'].default || middleware['super-admin']

export default middleware
