import { createToastInterface } from "vue-toastification";

export default function (ctx, inject) {
  const toast = createToastInterface({"cssFile":"E:\\0namica\\htdocs\\frontendNuxt\\node_modules\\vue-toastification\\dist\\index.css","timeout":1000,"draggable":true});
  inject('toast', toast);
}
