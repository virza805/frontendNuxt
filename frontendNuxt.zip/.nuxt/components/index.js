export { default as AccordionItem } from '../..\\components\\accordion-item.vue'
export { default as Accordion } from '../..\\components\\accordion.vue'
export { default as ContactInfo } from '../..\\components\\ContactInfo.vue'
export { default as Dropdown } from '../..\\components\\Dropdown.vue'
export { default as Footer } from '../..\\components\\Footer.vue'
export { default as Header } from '../..\\components\\Header.vue'
export { default as Logo } from '../..\\components\\Logo.vue'
export { default as Sidebar } from '../..\\components\\Sidebar.vue'
export { default as SingleProductBox } from '../..\\components\\SingleProductBox.vue'
export { default as SingleProductBoxssss } from '../..\\components\\SingleProductBoxssss.vue'
export { default as Tanvir } from '../..\\components\\Tanvir.vue'
export { default as TextSlid } from '../..\\components\\TextSlid.vue'
export { default as Toaster } from '../..\\components\\Toaster.vue'
export { default as UserRole } from '../..\\components\\UserRole.vue'
export { default as FormButton } from '../..\\components\\Form\\button.vue'
export { default as FormInput } from '../..\\components\\Form\\Input.vue'
export { default as FormTextarea } from '../..\\components\\Form\\Textarea.vue'
export { default as BackendClock } from '../..\\components\\Backend\\Clock.vue'
export { default as BackendDigitalClock } from '../..\\components\\Backend\\DigitalClock.vue'
export { default as BackendDropdown } from '../..\\components\\Backend\\dropdown.vue'
export { default as BackendEmailVerificationStatus } from '../..\\components\\Backend\\email-verification-status.vue'
export { default as BackendFooter } from '../..\\components\\Backend\\Footer.vue'
export { default as BackendHeader } from '../..\\components\\Backend\\Header.vue'
export { default as BackendLeftSidebarMenu } from '../..\\components\\Backend\\LeftSidebarMenu.vue'

// nuxt/nuxt.js#8607
function wrapFunctional(options) {
  if (!options || !options.functional) {
    return options
  }

  const propKeys = Array.isArray(options.props) ? options.props : Object.keys(options.props || {})

  return {
    render(h) {
      const attrs = {}
      const props = {}

      for (const key in this.$attrs) {
        if (propKeys.includes(key)) {
          props[key] = this.$attrs[key]
        } else {
          attrs[key] = this.$attrs[key]
        }
      }

      return h(options, {
        on: this.$listeners,
        attrs,
        props,
        scopedSlots: this.$scopedSlots,
      }, this.$slots.default)
    }
  }
}
