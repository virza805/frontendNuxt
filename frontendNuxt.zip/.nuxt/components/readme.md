# Discovered Components

This is an auto-generated list of components discovered by [nuxt/components](https://github.com/nuxt/components).

You can directly use them in pages and other components without the need to import them.

**Tip:** If a component is conditionally rendered with `v-if` and is big, it is better to use `Lazy` or `lazy-` prefix to lazy load.

- `<AccordionItem>` | `<accordion-item>` (components/accordion-item.vue)
- `<Accordion>` | `<accordion>` (components/accordion.vue)
- `<ContactInfo>` | `<contact-info>` (components/ContactInfo.vue)
- `<Dropdown>` | `<dropdown>` (components/Dropdown.vue)
- `<Footer>` | `<footer>` (components/Footer.vue)
- `<Header>` | `<header>` (components/Header.vue)
- `<Logo>` | `<logo>` (components/Logo.vue)
- `<Sidebar>` | `<sidebar>` (components/Sidebar.vue)
- `<SingleProductBox>` | `<single-product-box>` (components/SingleProductBox.vue)
- `<SingleProductBoxssss>` | `<single-product-boxssss>` (components/SingleProductBoxssss.vue)
- `<Tanvir>` | `<tanvir>` (components/Tanvir.vue)
- `<TextSlid>` | `<text-slid>` (components/TextSlid.vue)
- `<Toaster>` | `<toaster>` (components/Toaster.vue)
- `<UserRole>` | `<user-role>` (components/UserRole.vue)
- `<FormButton>` | `<form-button>` (components/Form/button.vue)
- `<FormInput>` | `<form-input>` (components/Form/Input.vue)
- `<FormTextarea>` | `<form-textarea>` (components/Form/Textarea.vue)
- `<BackendClock>` | `<backend-clock>` (components/Backend/Clock.vue)
- `<BackendDigitalClock>` | `<backend-digital-clock>` (components/Backend/DigitalClock.vue)
- `<BackendDropdown>` | `<backend-dropdown>` (components/Backend/dropdown.vue)
- `<BackendEmailVerificationStatus>` | `<backend-email-verification-status>` (components/Backend/email-verification-status.vue)
- `<BackendFooter>` | `<backend-footer>` (components/Backend/Footer.vue)
- `<BackendHeader>` | `<backend-header>` (components/Backend/Header.vue)
- `<BackendLeftSidebarMenu>` | `<backend-left-sidebar-menu>` (components/Backend/LeftSidebarMenu.vue)
